package com.example.productdervicefeb25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductServiceFeb25Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductServiceFeb25Application.class, args);
	}

}
