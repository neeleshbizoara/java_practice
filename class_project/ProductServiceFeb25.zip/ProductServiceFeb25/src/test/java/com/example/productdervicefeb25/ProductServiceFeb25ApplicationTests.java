package com.example.productdervicefeb25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServiceFeb25ApplicationTests {

	@Test
	void contextLoads() {
	}

}
